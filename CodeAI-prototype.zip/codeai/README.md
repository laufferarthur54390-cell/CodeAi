# CodeAI — prototype

## Installation
1. Installe Node.js.
2. Ouvre un terminal dans ce dossier.
3. Lance `npm install`.
4. Lance `npm start`.
5. Ouvre http://localhost:3000

Cette version contient l'interface et un faux moteur de génération pour tester le site.
La prochaine étape consiste à connecter un vrai modèle d'IA au backend.
